package com.example.FoodData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodDataApplication.class, args);
	}

}
