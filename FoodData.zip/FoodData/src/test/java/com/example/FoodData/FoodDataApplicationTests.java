package com.example.FoodData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
