
package com.foods.food1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foods.food1.dao.Food1;
import com.foods.food1.repository.Food1Repository;

@Service
public class Food1Service {
	@Autowired
	
	Food1Repository fdrtRepository;
	
	public List<Food1> getAllFood1()
	{
		List<Food1> f1List=fdrtRepository.findAll();
		return f1List;
	}
	
	public Food1 saveFood1(Food1 f) 
	{
		Food1 obj = fdrtRepository.save(f);
		return obj;
		//return fRepository.save(f);	
	}
	
	public Food1 updateFood1(Food1 f) 
	{
		return fdrtRepository.save(f);
	}
	
	public void deleteFood1(int f1) 
	{
		fdrtRepository.deleteById(f1);
	}

	
//		public static void deleteById(int food1) {
//		// TODO Auto-generated method stub
//	}
}


