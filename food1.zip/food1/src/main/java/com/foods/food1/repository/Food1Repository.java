package com.foods.food1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foods.food1.dao.Food1;

public interface Food1Repository extends JpaRepository <Food1,Integer> {

}
