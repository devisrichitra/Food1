package com.foods.food1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.foods.food1.dao.Food1;
import com.foods.food1.service.Food1Service;

@RestController
	public class Food1Controller {
		
		@Autowired
		Food1Service f1Service;
		
		@GetMapping("/get")
		public List<Food1> getAllFood1()
		{
			List<Food1>fdrtList=f1Service.getAllFood1();
			return fdrtList;
		}
		@PostMapping(value="/saveFood1")
		public Food1 saveFood1(@RequestBody Food1 f)
		{
			return f1Service.saveFood1(f);
			
		}
		@PutMapping(value="/updateFood1")
		public Food1 updateFood1(@RequestBody Food1 f)
		{
			return f1Service.updateFood1(f);
			
		}
			@DeleteMapping("/deleteFood1/{f1}")
	public void deleteFood1(@PathVariable("f1") int food){
				f1Service.deleteFood1(food);
			}
}
			

			
//			Food1Service.deleteById(food1);
//			
//		}
	
