package com.foods.food1.dao;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Food1 {
	@Id
	private int foodrate ;
	private String fooditem;
	private int quantity;
	private int offer;
	public int getfoodrate() {
		return foodrate;
	}
	public void setfoodrate(int foodrate) {
		this.foodrate = foodrate;
	}
	public String getfooditem() {
		return fooditem;
	}
	public void set(int quantity) {
		this.setQuantity(quantity);
	}
	public int offer() {
		return offer;
	}
	public void setoffer(int offer) {
		this.offer = offer;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}





